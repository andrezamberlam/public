import { OpaqueToken } from '@angular/core';

export const BASE_PATH = new OpaqueToken('basePath');